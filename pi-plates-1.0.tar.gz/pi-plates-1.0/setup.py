from setuptools import setup, find_packages
setup(
    name='pi-plates',
    version='1.0',
    license='BSD',
    author='wally',
    author_email='support@pi-plates.com',
    url='http://www.pi-plates.com',
    long_description="README.txt",
    packages=['piplates'],
    include_package_data=True,
    package_data={'' : ['ppDAQChelp.txt']},
    description="Pi-Plates testing setuptools",
)